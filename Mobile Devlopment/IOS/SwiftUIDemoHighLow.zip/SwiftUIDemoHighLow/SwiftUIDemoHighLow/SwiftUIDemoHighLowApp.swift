//
//  SwiftUIDemoHighLowApp.swift
//  SwiftUIDemoHighLow
//
//  Created by Maxwell, Jeff on 3/18/21.
//

import SwiftUI

@main
struct SwiftUIDemoHighLowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
