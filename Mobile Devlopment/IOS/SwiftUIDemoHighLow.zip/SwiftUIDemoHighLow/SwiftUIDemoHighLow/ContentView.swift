//
//  ContentView.swift
//  SwiftUIDemoHighLow
//
//  Created by Maxwell, Jeff on 3/18/21.
//

import SwiftUI

struct ContentView: View {
    @State var card = Card(suit: 1, number: 1)
    @State var cardName: String = "card_3_11"
    @State var suit: Int = 4
    @State var cardNumber: Int = 3
    @State var score: Int = 0
    @State var scoreLabel: String = "Score: 0"
    @State var previousNumber: Int = 0
    var body: some View {
        ZStack {
            Image("green_background")
                .resizable()
                .edgesIgnoringSafeArea(.all)
            VStack {
                Spacer()
                
                Button(action: {
                    print("High")
                    self.previousNumber = self.cardNumber
                    self.suit = Int.random(in: 1...4)
                    self.cardNumber = Int.random(in: 1...13)
                    self.cardName = "card_\(self.suit)_\(self.cardNumber)"
                    if self.cardNumber > self.previousNumber {
                        self.score += 1
                        self.scoreLabel = "Score: \(score)"
                    } else {
                        self.score -= 1
                        self.scoreLabel = "Score: \(score)"
                    }
                    
                }, label: {
                    Image("high")
                })
                
                               
                Spacer()
                Image(self.cardName)
                    .resizable()
                    .scaledToFit()
                Spacer()
                Image("low")
                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/, 20)
                Spacer()
                Text(self.scoreLabel)
                    .bold()
                    .foregroundColor(.white)
                    .font(.largeTitle)
                Spacer()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
