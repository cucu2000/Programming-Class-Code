//
//  Card.swift
//  SwiftUIDemoHighLow
//
//  Created by Maxwell, Jeff on 3/18/21.
//

import Foundation
class Card {
    var suit: Int = 1
    var number: Int = 1
    var previous: Int = 0
    var name: String
    
    init(suit: Int, number: Int) {
        self.suit = suit
        self.number = number
        self.name = "card_\(self.suit)_\(self.number)"
    }
}
