//
//  ViewController.swift
//  H03_Cosgrave
//
//  Created by Cosgrave, Kaleb on 2/9/21.
//

import UIKit

class ViewController: UIViewController {

    let hello = "Hello "

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var txtfldInput: UITextField!
    
    @IBOutlet weak var lblOutput: UILabel!
    
    @IBAction func btnSayHello(_ sender: UIButton) {
        
        lblOutput.text = "\(hello) \(String(txtfldInput.text!))"
        
    }
}

