//call change
let change = Change(moneyPaid: 50, totalBill: 25)

//call getChange

print(change.getChange(moneyPaid: 10.00, totalBill: 10.00))

print(change.getChange(moneyPaid: 10.00, totalBill: 8.25))

print(change.getChange(moneyPaid: 100.00, totalBill: 80.10))

print(change.getChange(moneyPaid: 10.00, totalBill: 11.25))