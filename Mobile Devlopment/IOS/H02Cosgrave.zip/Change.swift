class Change{
  
  //set variables
  var totalBill = 0.0

  var moneyPaid = 0.0
 
 //init
 init(moneyPaid: Double, totalBill: Double){
    setMoneyPaid(moneyPaid: moneyPaid)
    setTotalBill(totalBill: totalBill)
    print(getChange(moneyPaid: moneyPaid, totalBill: totalBill))
 }
 //getters and setters
 func getTotalBill () -> (Double){
   return totalBill
 }

 func setTotalBill (totalBill: Double) {
   self.totalBill = totalBill
 }

 func getMoneyPaid () -> (Double){
   return moneyPaid
 }

 func setMoneyPaid (moneyPaid: Double) {
   self.moneyPaid = moneyPaid
 }

//Change ctr
 func getChange (moneyPaid: Double, totalBill: Double) -> [Int]?  {

   //set variables
    var amountRemaining = 0.00

    var twentys = 0 
    var tens = 0 
    var fives = 0 
    var ones = 0 
    var quarters = 0 
    var dimes = 0 
    var nickels = 0 
    var pennies = 0 

    //get remaing amount
    amountRemaining = moneyPaid - totalBill


    //get the change due
    if amountRemaining < 0{
      return nil

    }else{
      twentys = Int(amountRemaining/20)
      amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 20)

      tens = Int(amountRemaining/10)
       amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 10)

      fives = Int(amountRemaining/5)
       amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 5)

      ones = Int(amountRemaining/1)
       amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 1)

      quarters = Int(amountRemaining/0.25)
       amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 0.25)

      dimes = Int(amountRemaining/0.1)
      amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 0.1)

      nickels = Int(amountRemaining/0.05)
       amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 0.05)

      pennies = Int(amountRemaining/0.01)
       amountRemaining = amountRemaining.truncatingRemainder(dividingBy: 0.01)
      
      return [twentys, tens, fives, ones, quarters, dimes, nickels, pennies]
    }  
 }
}