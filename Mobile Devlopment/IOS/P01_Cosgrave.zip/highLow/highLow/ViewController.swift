//
//  ViewController.swift
//  highLow
//
//  Created by Cosgrave, Kaleb on 2/2/21.
//

import UIKit

class ViewController: UIViewController {

    var score = 0
    var previousCard = 0
    var currentCard = 0
    var remainingCard = 5
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        imgCard.image = UIImage(named: nextCard())
    }
    
    func nextCard() -> (String){
        previousCard = self.currentCard
        
        let suit = Int.random(in: 1...4)
        
        let cardNum = Int.random(in: 1...13)
        
        let fullCard = "card_\(suit)_\(cardNum)"
        
        currentCard = cardNum
        imgCard.image = UIImage(named: fullCard)
        print(fullCard)
        
        return fullCard
    }
    
    func checkRemainingCard() {
        remainingCard -= 1
        if remainingCard == 0{
            self.performSegue(withIdentifier: "Game Over", sender: self)
        }
    }
    
    func checkCard(input: String) {
        
        nextCard()
        
        if input == "high" && currentCard > previousCard {
            if score == 0 {
            score += 1
            }else if score < 0{
            score /= 2
            }else{
                score *= 2
            }
            
        }else if input == "high" && currentCard == previousCard {
            score += 0
            
        }else if input == "low" && currentCard < previousCard {
            if score == 0{
                score += 1
            }else if score < 0{
                score /= 2
            }else{
                score *= 2
            }
            
        }else if input == "low" && currentCard == previousCard {
            score += 0
            
        }else{
            if score > 1{
                score /= 2
            }else if score == 1 || score == 0{
                score -= 1
            }else{
             score *= 2
            }
        }
        checkRemainingCard()
        lblScore.text = String(score)
    }
    
    @IBAction func btnHigh(_ sender: UIButton){
        print("high")
        checkCard(input: "high")
        
    }
    
    @IBAction func btnLow(_ sender: UIButton) {
        print("low")
        checkCard(input: "low")
    }
    
    @IBOutlet weak var lblScore: UILabel!
    
    @IBOutlet weak var imgCard: UIImageView!
}

