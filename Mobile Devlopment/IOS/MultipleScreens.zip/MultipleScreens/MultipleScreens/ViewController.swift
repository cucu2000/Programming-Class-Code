//
//  ViewController.swift
//  MultipleScreens
//
//  Created by Maxwell, Jeff on 2/9/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func navButtonTapped(_ sender: UIButton) {
        
        guard let vc = self.storyboard?.instantiateViewController(identifier: "secondVC") as? SecondViewController else {
            print("Could not find 2nd View Controller")
            return
        }
        
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func buttonTapped(_ sender: UIButton) {
        
//        let vc = SecondViewController(nibName: "secondVC", bundle: nil)
        
//        vc.name = "Jeff Maxwell"
        
        performSegue(withIdentifier: "segueSecond", sender: self)
    }
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is SecondViewController {
            let vc = segue.destination as? SecondViewController
            
            vc?.name = "Jeff"
        }
    }
 
}

