//
//  SecondViewController.swift
//  MultipleScreens
//
//  Created by Maxwell, Jeff on 2/9/21.
//

import UIKit

class SecondViewController: UIViewController {
    var name: String = ""

    @IBOutlet weak var nameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameLabel?.text = name;
    }

    @IBAction func dismissedTapped(_ sender: UIButton) {
        
        dismiss(animated: true, completion: nil)
    }
    
}
