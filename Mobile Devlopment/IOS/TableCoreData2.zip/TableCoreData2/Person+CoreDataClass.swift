//
//  Person+CoreDataClass.swift
//  TableCoreData2
//
//  Created by Maxwell, Jeff on 3/2/21.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
