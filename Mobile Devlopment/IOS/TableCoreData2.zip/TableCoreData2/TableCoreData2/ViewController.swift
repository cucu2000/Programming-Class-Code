//
//  ViewController.swift
//  TableCoreData2
//
//  Created by Maxwell, Jeff on 3/2/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var items:[Person]?
    
    func loadData() {
        do {
            self.items = try self.context.fetch(Person.fetchRequest())
            self.tableView.reloadData()
        } catch {
            print("Error loading data")
        }
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let person = self.items![indexPath.row]
        
        print(person.name)
        cell.textLabel?.text = person.name
        cell.detailTextLabel?.text = String(person.age)
        
        return cell
    }
    

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.loadData()
        
    }

    @IBAction func addTapped(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Add Person", message: "Enter the persons name", preferredStyle: .alert)
        
        alert.addTextField()
        alert.addTextField()
        
        let submitButton = UIAlertAction(title: "Add", style: .default) { (action) in
            let textField = alert.textFields![0]
            
            let newPerson = Person(context: self.context)
            newPerson.name = textField.text
            newPerson.age = Int64.random(in: 1...100)
            
            self.saveAndRefresh()
        }
        
        alert.addAction(submitButton)
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let delete = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
            
            let personToDelete = self.items![indexPath.row]
            
            self.context.delete(personToDelete)
            
            self.saveAndRefresh()
        }
        
        delete.backgroundColor = .red
        let config = UISwipeActionsConfiguration(actions: [delete])
        
        return config
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "Edit Person", message: "Enter the name", preferredStyle: .alert)
        
        alert.addTextField()
        
        let person = self.items![indexPath.row]
        
        let textField = alert.textFields![0]
        
        textField.text = person.name
        
        let saveButton = UIAlertAction(title: "Save", style: .default) { (action) in
            
            let textField2 = alert.textFields![0]
            person.name = textField2.text
            
            self.saveAndRefresh()
         }
        
        alert.addAction(saveButton)
        self.present(alert, animated: true, completion: nil)
    }
    
    func saveAndRefresh() {
        do {
            try self.context.save()
            self.loadData()
        } catch {
            print("Error Saving")
        }
    }
    
}

