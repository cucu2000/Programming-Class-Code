import UIKit

class ViewController: UIViewController {
    struct User: Codable {
        var userId: Int
        var id: Int
        var title: String
        var body: String
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getSWData()
        //self.getData()
    }
    
    func getSWData() {
        guard let url = URL(string: "https://swapi.dev/api/people") else {
            print("Bad URL")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url) {
            (data, response, error) in
            
            guard error == nil else {
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try decoder.decode(Characters.self, from: data)
                for p in decodedData.results {
                    print(p.name)
                }
//                print(decodedData.name)
            } catch {
                print(error.localizedDescription)
            }
        }
        dataTask.resume()
    }

    func getData() {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
            print("Bad URL")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url) {
            (data, response, error) in
            
            guard error == nil else {
                print(error?.localizedDescription)
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                let decoder = JSONDecoder()
                
                let decodedData = try decoder.decode([User].self, from: data)
                
                for d in decodedData {
                    print(d.title)
                }
                
//                print(decodedData.title)
            } catch {
                print(error.localizedDescription)
            }
        }
        
        dataTask.resume()
        
        
    }

}

