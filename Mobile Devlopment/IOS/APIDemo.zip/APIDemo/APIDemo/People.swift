//
//  People.swift
//  APIDemo
//
//  Created by Maxwell, Jeff on 3/4/21.
//

import Foundation

struct People: Codable {
    var name: String
    var height: String
    var mass: String
}
