//
//  Characters.swift
//  APIDemo
//
//  Created by Maxwell, Jeff on 3/4/21.
//

import Foundation

struct Characters: Codable {
    var results: [People]
}
