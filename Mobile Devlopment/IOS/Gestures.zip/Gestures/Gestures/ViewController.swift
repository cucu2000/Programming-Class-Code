//
//  ViewController.swift
//  Gestures
//
//  Created by Maxwell, Jeff on 3/9/21.
//

import UIKit

class ViewController: UIViewController {
    
    enum Action: CaseIterable {
        case SwipeUp
        case SwipeDown
        case SwipeRight
        case SwipeLeft
        case Tap
        case Pinch
    }
    
    var gesture = Action.Tap
    var secondsRemaining = 10
    var score = 0

    @IBOutlet weak var actionLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var timeRemainingLabel: UILabel!
    
    @IBAction func pinchHandler(_ sender: UIPinchGestureRecognizer) {
        //actionLabel.text = "Pinched"
        if gesture == .Pinch {
            addToScore()
        }
    }
    @IBAction func swipeHandler(_ sender: UISwipeGestureRecognizer) {
        
        switch sender.direction {
            case UISwipeGestureRecognizer.Direction.right:
                //actionLabel.text = "Swipe Right"
                if gesture == .SwipeRight {
                    addToScore()
                }
            case UISwipeGestureRecognizer.Direction.left:
                //actionLabel.text = "Swipe Left"
                if gesture == .SwipeLeft {
                    addToScore()
                }
            case UISwipeGestureRecognizer.Direction.up:
                //actionLabel.text = "Swipe Up"
                if gesture == .SwipeUp {
                    addToScore()
                }
            case UISwipeGestureRecognizer.Direction.down:
                actionLabel.text = "Swipe Down"
                if gesture == .SwipeDown {
                    addToScore()
                }
            default:
                actionLabel.text = "No Swipe Found"
                break
        }
        
    }
    
    @IBAction func tabHandler(_ sender: UITapGestureRecognizer) {
        //actionLabel.text = "Tapped"
        if gesture == .Tap {
            addToScore()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreLabel.text = "Score: \(score)"
        timeRemainingLabel.text = String(secondsRemaining)
        startTimer()
        pickRandomGesture()
    }
    
    func addToScore() {
        score += 1
        scoreLabel.text = "Score: \(score)"
        // Reset Gesture
        pickRandomGesture()
    }
    
    func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer: Timer) in
            self.secondsRemaining -= 1
            
            if self.secondsRemaining == 0 {
                timer.invalidate()
                self.timeRemainingLabel.text = "Game Over"
            }
            
            self.timeRemainingLabel.text = String(self.secondsRemaining)
        }
    }
    
    func pickRandomGesture() {
        
        gesture = Action.allCases.randomElement()!
        
        switch gesture {
        case Action.Pinch:
            actionLabel.text = "Pinch"
        case .SwipeDown:
            actionLabel.text = "Swipe Down"
        case .SwipeUp:
            actionLabel.text = "Swipe Up"
        case .SwipeLeft:
            actionLabel.text = "Swipe Left"
        case .SwipeRight:
            actionLabel.text = "Swipe Right"
        case .Tap:
            actionLabel.text = "Tap"
        }
        
    }


}

