//
//  ContentView.swift
//  H06_Cosgrave
//
//  Created by Cosgrave, Kaleb on 4/8/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var output: String = ""
    
    var body: some View {
        
        VStack(alignment: .center){
            
            if !output.isEmpty {
                
                Text("Hello \(output)")
                
            }
                
                TextField("Enter Text", text: $output)
                    .padding()
                    .multilineTextAlignment(.center)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
