//
//  H06_CosgraveApp.swift
//  H06_Cosgrave
//
//  Created by Cosgrave, Kaleb on 4/8/21.
//

import SwiftUI

@main
struct H06_CosgraveApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
