//
//  ViewController.swift
//  HelloWorld
//
//  Created by Maxwell, Jeff on 1/26/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let y = 10
        
        var x = 5
        x = 20
        
        
    }


}

