//
//  ViewController.swift
//  HighLow
//
//  Created by Maxwell, Jeff on 2/2/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var scoreLabel: UILabel!

    var score = 0
    var currentCardNumber = 0
    var previousCardNumber = 0
    
    @IBAction func touchHigh(_ sender: UIButton) {
        randomCard()
        if currentCardNumber > previousCardNumber {
            score += 1
        } else if currentCardNumber < previousCardNumber {
            score -= 1
        }
        
        scoreLabel.text = String(score)
    }
   
    @IBAction func touchLow(_ sender: UIButton) {
        randomCard()
        if currentCardNumber > previousCardNumber {
            score -= 1
        } else if currentCardNumber < previousCardNumber {
            score += 1
        }
        
        scoreLabel.text = String(score)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        randomCard()
    }
    
    func randomCard() {
        previousCardNumber = currentCardNumber
        
        let suitNumber = Int.random(in: 1...4)
        currentCardNumber = Int.random(in: 1...13)
        
        let cardName = "card_\(suitNumber)_\(currentCardNumber)"
        
        imgView.image = UIImage(named: cardName)

    }
    
}

