//
//  TableViewController.swift
//  H05_Cosgrave
//
//  Created by Cosgrave, Kaleb on 3/25/21.
//

import UIKit

class TableViewController: UITableViewController {

var output = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 100
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        cell.textLabel?.text = "Element \(indexPath.row)"
        cell.accessoryType = .disclosureIndicator

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        output = "Element \(indexPath.row)"
        
        performSegue(withIdentifier: "tableSeque", sender: self)
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.destination is outputController {
            let vc = segue.destination as? outputController
            vc?.output = output
           
        }
    }
}
