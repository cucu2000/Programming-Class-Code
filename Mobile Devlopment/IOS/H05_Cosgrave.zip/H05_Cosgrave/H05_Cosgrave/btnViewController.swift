//
//  btnViewController.swift
//  H05_Cosgrave
//
//  Created by Cosgrave, Kaleb on 3/25/21.
//

import UIKit

class btnViewController: UIViewController {

    @IBOutlet weak var txtfldText: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func SendText(_ sender: Any) {
        performSegue(withIdentifier: "btnSeque", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.destination is outputController {
            let vc = segue.destination as? outputController
            
            vc?.output = txtfldText.text!
        }
    }
}
