//
//  outputController.swift
//  H05_Cosgrave
//
//  Created by Cosgrave, Kaleb on 3/30/21.
//

import UIKit

class outputController: UIViewController {

    var output = " "
    @IBOutlet weak var lblOutput: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblOutput.text = output
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
