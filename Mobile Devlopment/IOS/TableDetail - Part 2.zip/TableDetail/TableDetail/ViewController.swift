//
//  ViewController.swift
//  TableDetail
//
//  Created by Maxwell, Jeff on 2/23/21.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    
    var selectedRow: Int = 0
    var items = ["Jim", "Joe", "Sally", "Cindy", "Jeff"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell = UITableViewCell()
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = items[indexPath.row]
        cell.imageView?.image = UIImage(named: "mascot2")
        cell.accessoryType = .disclosureIndicator
        
        print(indexPath.row)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Row Selected \(indexPath.row)")
        
        selectedRow = indexPath.row
        
        performSegue(withIdentifier: "tableSegue", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is SecondViewController {
            let secondVC = segue.destination as? SecondViewController
            
            segue.destination.title = "Hello \(selectedRow)"
            
            secondVC?.name = "World \(selectedRow)"
        }
    }
    
    private func handleLike() {
        print("You like it")
    }
    
    private func handleDelete(row: Int) {
        print("Delete row \(row)" )
        print(items)
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let like = UIContextualAction(style: .normal, title: "Like") { (action, view, completionHandler) in
            self.handleLike()
            completionHandler(true)
        }
        
        like.backgroundColor = .green
        let config = UISwipeActionsConfiguration(actions: [like])
        return config
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
            self.items.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            self.handleDelete(row: indexPath.row)
        }
        
        delete.backgroundColor = .red
        
        let follow = UIContextualAction(style: .normal, title: "Follow") { (action, view, completionHandler) in
            print("Following")
            completionHandler(true)
        }
        
        follow.backgroundColor = .blue
                
        let config = UISwipeActionsConfiguration(actions: [delete, follow])
        config.performsFirstActionWithFullSwipe = true
        
        return config
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

