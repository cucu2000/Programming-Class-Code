//
//  ViewController.swift
//  ImagePicker
//
//  Created by Maxwell, Jeff on 2/23/21.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var convertedImage: UIImageView!
    @IBOutlet weak var origImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func convertButtonPressed(_ sender: UIButton) {
//        let context = CIContext(options: nil)
        
        let image = CIImage(image: origImage.image!)
        
        // www.cifilter.io
        let filter = CIFilter(name: "CIGaussianBlur", parameters:
                [
                    "inputImage": image!,
                    "inputRadius": 20
                ])
        let outputImage = filter?.outputImage
        convertedImage.image = UIImage(ciImage: outputImage!)
        
    }
    
    @IBAction func loadButtonPressed(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        
        imagePickerController.delegate = self
        
        self.present(imagePickerController, animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        print("Dismissed Photo Library")
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            return
        }
        
        origImage.image = image
        
        picker.dismiss(animated: true, completion: nil)
    }
}

