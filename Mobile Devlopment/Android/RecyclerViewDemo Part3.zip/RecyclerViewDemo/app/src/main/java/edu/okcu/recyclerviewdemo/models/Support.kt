package edu.okcu.recyclerviewdemo.models

data class Support(
    val text: String,
    val url: String
)