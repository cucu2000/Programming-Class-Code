package edu.okcu.recyclerviewdemo

import edu.okcu.recyclerviewdemo.models.Card

interface OnCardClickListner {
    fun OnCardClick(card: Card)
}