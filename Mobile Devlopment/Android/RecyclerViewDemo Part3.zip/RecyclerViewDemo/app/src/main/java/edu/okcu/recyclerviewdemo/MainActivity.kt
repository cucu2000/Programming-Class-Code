package edu.okcu.recyclerviewdemo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.GsonBuilder
import edu.okcu.recyclerviewdemo.models.Card
import edu.okcu.recyclerviewdemo.models.User
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity(), OnCardClickListner {
    var cards: ArrayList<Card> = ArrayList()
    lateinit var layoutManager : RecyclerView.LayoutManager
    lateinit var adapter: RecyclerView.Adapter<CardAdapter.ViewHolder>
    var count: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadCards()
        //loadJSON()

        layoutManager = LinearLayoutManager(this)
        var recyclerView = findViewById<RecyclerView>(R.id.view_recycler)
        recyclerView.layoutManager = layoutManager

        adapter = CardAdapter(cards, this)
        recyclerView.adapter = adapter
    }

    fun loadJSON() {
        val url = "https://reqres.in/api/users"
        val request = Request.Builder().url(url).build()
        val client = OkHttpClient()

        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d("ERROR", e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                Log.d("JSON", body.toString())

                val gson = GsonBuilder().create()
                var user = gson.fromJson(body, User::class.java)

                runOnUiThread {
                    var recyclerView = findViewById<RecyclerView>(R.id.view_recycler)
                    recyclerView.adapter = UserAdapter(user)
                }

            }

        })

    }

    fun loadCards() {
        for(suit in 1..4) {
            for (card in 1..13) {
                cards.add(Card(suit, card))
            }
        }
    }

    override fun OnCardClick(card: Card) {
        if(card.Found) {
            count += 1
        } else {
            count -= 1
        }

        var txtCount = findViewById<TextView>(R.id.textview_count)
        txtCount.text = count.toString()
        
//        val activityIntent = Intent(this, CardDetailActivity::class.java)
//        activityIntent.putExtra("CARD_NAME", card.Card)
//        activityIntent.putExtra("CARD_SUIT", card.Suit)
//        activityIntent.putExtra("CARD_IMAGE", card.CardImage)
//        startActivity(activityIntent)
    }
}