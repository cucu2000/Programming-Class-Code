package edu.okcu.recyclerviewdemo

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class CardDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card_detail)

        val textSuit = findViewById<TextView>(R.id.detail_text_suit)
        textSuit.text = intent.getStringExtra("CARD_SUIT")

        val textCard = findViewById<TextView>(R.id.detail_text_card)
        textCard.text = intent.getStringExtra("CARD_NAME")

        val imageCard = findViewById<ImageView>(R.id.detail_image_card)
        val cardImageName = intent.getStringExtra("CARD_IMAGE")

        val uri: Uri = Uri.parse("android.resource://edu.okcu.recyclerviewdemo/drawable/${cardImageName}")
        imageCard.setImageURI(uri)

    }
}