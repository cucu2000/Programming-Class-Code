package edu.okcu.recyclerviewdemo

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import edu.okcu.recyclerviewdemo.models.Card

class CardAdapter(
    var cards: ArrayList<Card>,
    var mainActivity: MainActivity
) : RecyclerView.Adapter<CardAdapter.ViewHolder>() {
    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        var itemImage: ImageView = itemView.findViewById(R.id.detail_image_card)
        var itemText: TextView = itemView.findViewById(R.id.text_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_card, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return cards.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemText.text = "${cards[position].Card} of ${cards[position].Suit}"

        var uri: Uri = Uri.parse("android.resource://edu.okcu.recyclerviewdemo/drawable/${cards[position].CardImage}")

        holder.itemImage.setImageURI(uri)

        holder.itemView.setOnClickListener {
            mainActivity.OnCardClick(cards[position])
        }
    }

}