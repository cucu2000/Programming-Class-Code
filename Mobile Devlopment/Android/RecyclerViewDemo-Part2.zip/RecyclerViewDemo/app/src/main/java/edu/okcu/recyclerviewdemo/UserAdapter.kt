package edu.okcu.recyclerviewdemo

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import edu.okcu.recyclerviewdemo.models.Card
import edu.okcu.recyclerviewdemo.models.User

class UserAdapter(
    var user: User
) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        var itemImage: ImageView = itemView.findViewById(R.id.detail_text_card)
        var itemText: TextView = itemView.findViewById(R.id.text_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_card, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return user.data.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemText.text = "${user.data[position].first_name} ${user.data[position].last_name}"

        //holder.itemImage
        Picasso
            .get()
            .load(user.data[position].avatar)
            .into(holder.itemImage)

//        var uri: Uri = Uri.parse("android.resource://edu.okcu.recyclerviewdemo/drawable/${cards[position].CardImage}")

//        holder.itemImage.setImageURI(uri)


    }

}