package edu.okcu.multiplepages


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fabNext = findViewById<FloatingActionButton>(R.id.fab_next)

        fabNext.setOnClickListener {
            buttonAddClick()
        }

    }

    fun buttonAddClick() {
        val textFirstName = findViewById<EditText>(R.id.text_first_name)

        val activityIntent = Intent(this, SecondActivity::class.java)
        activityIntent.putExtra(FIRST_NAME, textFirstName.text.toString())
        startActivity(activityIntent)
    }
}