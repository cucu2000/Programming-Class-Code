package edu.okcu.multiplepages

const val FIRST_NAME = "FIRST_NAME"