package com.example.weatherdemo.models

data class Coord(
    val lat: Double,
    val lon: Double
)