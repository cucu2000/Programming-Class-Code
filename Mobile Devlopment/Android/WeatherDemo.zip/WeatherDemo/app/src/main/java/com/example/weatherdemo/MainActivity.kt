package com.example.weatherdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherdemo.models.Weather
import com.google.gson.GsonBuilder
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val client = OkHttpClient()
        val url = "https://community-open-weather-map.p.rapidapi.com/weather"
        val location = "Dallas,US"
        val id = "2172797"
        val request = Request.Builder()
                .url("${url}?q=${location}&id=${id}&lat=0&lon=0&lang=null&units=%22metric%22%20or%20%22imperial%22&mode=xml%2C%20html")
                .get()
                .addHeader("x-rapidapi-key", "98d0499b1bmshdc26af1f86dcc4ep1ba1e8jsne2011c90bafe")
                .addHeader("x-rapidapi-host", "community-open-weather-map.p.rapidapi.com")
                .build()

        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d("ERROR", "API Call Failed")
            }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()

                val gson = GsonBuilder().create()
                var weather = gson.fromJson(body, Weather::class.java)

                Log.d("JSON", body.toString())

                Log.d("TEMP", weather.main.temp.toString());

                runOnUiThread() {
                }
            }
        })

    }
}