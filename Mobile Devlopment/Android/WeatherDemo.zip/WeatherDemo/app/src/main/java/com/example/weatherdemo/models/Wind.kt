package com.example.weatherdemo.models

data class Wind(
    val deg: Int,
    val speed: Double
)