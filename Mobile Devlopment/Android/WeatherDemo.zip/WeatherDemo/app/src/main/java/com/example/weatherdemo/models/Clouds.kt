package com.example.weatherdemo.models

data class Clouds(
    val all: Int
)