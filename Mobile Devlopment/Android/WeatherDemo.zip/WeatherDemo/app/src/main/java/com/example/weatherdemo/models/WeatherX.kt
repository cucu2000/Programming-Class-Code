package com.example.weatherdemo.models

data class WeatherX(
    val description: String,
    val icon: String,
    val id: Int,
    val main: String
)