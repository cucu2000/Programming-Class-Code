package edu.okcu.recyclerviewdemo

data class Card(var SuitNumber: Int, var CardNumber:Int) {
    var CardImage: String
    var Card: String
    var Suit: String

    init {
        this.CardImage = "card_${SuitNumber}_${CardNumber}"
        this.Card = getCard(CardNumber)
        this.Suit = getSuit(SuitNumber)
    }

    private fun getSuit(suit: Int): String {
        when(suit) {
            1 -> return "Hearts"
            2 -> return "Clubs"
            3 -> return "Diamonds"
            4 -> return "Spades"
        }
        return "Not Found"
    }

    private fun getCard(card: Int): String {
        when(card) {
            1 -> return "Ace"
            11 -> return "Jack"
            12 -> return "Queen"
            13 -> return "King"
        }
        return card.toString()
    }
}