package edu.okcu.recyclerviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    var cards: ArrayList<Card> = ArrayList()
    lateinit var layoutManager : RecyclerView.LayoutManager
    lateinit var adapter: RecyclerView.Adapter<CardAdapter.ViewHolder>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadCards()

        layoutManager = LinearLayoutManager(this)
        var recyclerView = findViewById<RecyclerView>(R.id.view_recycler)
        recyclerView.layoutManager = layoutManager

        adapter = CardAdapter(cards)
        recyclerView.adapter = adapter
    }

    fun loadCards() {
        for(suit in 1..4) {
            for (card in 1..13) {
                cards.add(Card(suit, card))
            }
        }
    }
}