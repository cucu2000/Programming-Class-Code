package edu.okcu.gesturesdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Toast
import kotlin.math.abs

class MainActivity : AppCompatActivity(), GestureDetector.OnGestureListener {

    lateinit var gestureDetector: GestureDetector
    var x1: Float = 0.0f
    var x2: Float = 0.0f
    var y1: Float = 0.0f
    var y2: Float = 0.0f
    val DISTANCE: Float = 200.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gestureDetector = GestureDetector(this, this)
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        gestureDetector.onTouchEvent(event)

         Log.d("XY", "X=${event?.x} Y=${event?.y}")

        when (event?.action) {
            0 -> {
                Log.d("XY", "Start X=${event?.x} Y=${event?.y}")
                x1 = event.x
                y1 = event.y
            }
            1 -> {
                Log.d("XY", "End X=${event?.x} Y=${event?.y}")
                x2 = event.x
                y2 = event.y
                if (abs(x2 - x1) > DISTANCE) {
                    if (x2 > x1) {
                        Toast.makeText(this, "Swipe Right", Toast.LENGTH_SHORT)
                                .show()
                    } else {
                        Toast.makeText(this, "Swipe Left", Toast.LENGTH_SHORT)
                                .show()
                    }
                } else if (abs(y2 - y1) > DISTANCE) {
                    if (y2 > y1) {
                        Toast.makeText(this, "Swipe Down", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Swipe Up", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }





        return super.onTouchEvent(event)
    }

    override fun onShowPress(e: MotionEvent?) {

    }

    override fun onSingleTapUp(e: MotionEvent?): Boolean {
        //Toast.makeText(this, "Single Tap Up", Toast.LENGTH_SHORT) .show()

        return false
    }

    override fun onDown(e: MotionEvent?): Boolean {
        //Toast.makeText(this, "Down", Toast.LENGTH_SHORT) .show()

        return false
    }

    override fun onFling(e1: MotionEvent?, e2: MotionEvent?, velocityX: Float, velocityY: Float): Boolean {
        //Toast.makeText(this, "Fling", Toast.LENGTH_SHORT)
        //        .show()

        return false
    }

    override fun onScroll(e1: MotionEvent?, e2: MotionEvent?, distanceX: Float, distanceY: Float): Boolean {
        //Toast.makeText(this, "Scroll", Toast.LENGTH_SHORT)
        //        .show()

        return false
    }

    override fun onLongPress(e: MotionEvent?) {
        //Toast.makeText(this, "Long Press", Toast.LENGTH_SHORT) .show()
    }
}